<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PDF Generator</title>
</head>
<body>

    <form action="generator.php" method="POST">
        <input type="text" name="ftext1" >
        <input type="text" name="ftext2" >
        <input type="text" name="ftext3" >
        <input type="text" name="ftext4" >
        <input type="submit">
    </form>


    <form action="" method='POST'>
        <span>Field1</span><input name="" required type="text" ><br>
        <span>Field2</span><input name="" required type="text" ><br>
        
    
    </form>
</body>
</html>