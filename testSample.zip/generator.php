<?php

use Classes\pdfGenerator;

if ($_SERVER["REQUEST_METHOD"] != 'POST'){
    exit;
}


require_once 'vendor/autoload.php';

$var1 = $_POST['ftext1'];
$var2 = $_POST['ftext2'];
$var3 = $_POST['ftext3'];
$var4 = $_POST['ftext4'];
$var5 = 'x';

$formFieldNames = array_keys($_POST);


$handle = fopen("fieldNames.txt", "r");
$fieldNames = array();
while(!feof($handle)){
    $data = fgets($handle);
    array_push($fieldNames, trim($data));
}
// print_r($fieldNames);

$data = array();
for ( $i = 0; $i < 4; $i++ ){
    $data[$fieldNames[$i]] = $_POST[$formFieldNames[$i]];
}
print_r($data);

// $data = [
//     'FillText1' => $var1,
//     'Text1' => $var2,
//     'CityCounty' => $var3,
//     'Text2' => $var4,
//     'Check Box4' => 'Yes'
// ];

// initializing the pdfGenerator class
$pdf = new pdfGenerator;
$response = $pdf->generate($data);



var_dump($response);